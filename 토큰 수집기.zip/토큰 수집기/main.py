import argparse
import csv
import requests

from concurrent.futures import ThreadPoolExecutor, as_completed


def fetch_token(i):
    try:
        url = f'http://172.16.24.158:8080/api/member/developer-get-token?id={i}'
        response = requests.get(url, timeout=3)
        if response.status_code == 200:
            result = response.json()
            if result.get('status') == 'success':
                print(f"[{i}] 저장 성공")
                return result['data']['accessToken']
            else:
                print(f"[{i}] 실패: {result.get('message')}")
        else:
            print(f"[{i}] HTTP 오류: {response.status_code}")
    except Exception as e:
        print(f"[{i}] 예외 발생: {e}")
    return None


def collect_tokens(start_id, end_id, output_file, max_workers=50):
    with open(output_file, mode='w', newline='') as file:
        writer = csv.writer(file)

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(fetch_token, i): i for i in range(start_id, end_id + 1)}

            for future in as_completed(futures):
                token = future.result()
                if token:
                    writer.writerow([token])


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='accessToken 수집기')
    parser.add_argument('--start', type=int, required=True, help='시작 ID')
    parser.add_argument('--end', type=int, required=True, help='끝 ID')
    parser.add_argument('--output', type=str, default='tokens.csv', help='저장할 CSV 파일명')
    parser.add_argument('--workers', type=int, default=50, help='최대 동시 요청 수')

    args = parser.parse_args()
    collect_tokens(args.start, args.end, args.output, args.workers)
